// xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
//
//  @Company name      : mikrolab GmbH
//  @Module_name       : NRIDDCMP
//  @Version           : $Revision: 2.3 $
//  @Target_processor  : 80x86
//  @Author            : H. Mueller
//  @Last_access       : 990414
//  @Access_before_last: 981218
//  @Description       : 
//  @History           : 
// 
// xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

typedef unsigned char uchar;
typedef unsigned int uint;
typedef unsigned long ulong;

#include "asynch_1.h"
#include <sys\types.h> 
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <fcntl.h>
#include <sys\stat.h> 
#include <conio.h>
#include <io.h>
#include <dos.h>
#include <string.h>


//#include "nrivars.h"
//#include "nriproto.h"
//#include "nrilit.h"
//#include "nrivhoef.h"


#define MAXQSIZE        1000    /* Groesse buffer fuer async-manager */
#define IROTBUFSIZE     260
#define IROTWRITEBYTES  235     /* +2(blockcnt)+2(CRC)+8(ACK)+8(DHDR) = 255 */
#define IRREADANZ       256
#define MAXERRRETRYSTART 20
#define MAXERRRETRY     40
#define ANZTRANSMITTYPS 7
#define FNAMSIZE        130     /* Laenge filename */

#define IRDATAFIRST     0x01            /* 1. Datenbuffer nach DHDR */
#define IRDATAAGAIN     0x02            /* 1. Datenbuffer wurde wiederholt */
#define IRDATACOMPLETE  0x04            /* letzter Datenbuffer zum DHDR */

#define SWVERSION 0
#define MANUNRI   8


#define IRT_PCWRITE     0
#define IRT_PCWRITECONF 1
#define IRT_PCREAD      2

//Phasen der Uebertragung
//Hilfsautomat
#define WT_STACK        0       /* warte auf Start ACK */
#define WT_ACK          1       /* warte auf ACK */
#define WT_ACKD         2       /* warte auf ACK und anschliessend DHDR */
#define WT_ACKF         3       /* warte auf final ACK (sometimes missing) */
#define WT_DHDR         4       /* warte auf Data Header */
#define WT_DATA         5       /* warte auf Data */
#define WT_START        6       /* warte auf START */
//Hauptautomat
#define S_START         0       /* START gesendet */
#define S_WAY           1       /* WAY   gesendet */
#define S_REFUSED       2       /* FINISH nach Ablehnung der Steuerung gesendet */
#define S_READRESP      3       /* READ-Anforderung gesendet */
#define S_PROGRESP      4       /* PROG-Anforderung gesendet */
#define S_WRITERESP     5       /* WRITE-Anforderung gesendet */
#define S_CLEARRESP     6       /* CLEAR-Anforderung gesendet */
#define S_READ          7       /* Daten werden empfangen */
#define S_READY         8       /* FINISH nach korrekter Uebertragung gesendet */
#define S_WRITE         9       /* Daten werden gesendet */



#define TICKCNT (*(volatile long far *)0x46cL)

#define CR 0x0d
#define LF 0x0a

int fd;
static char verboseflag = 0;

//Variable fuer serielles Interface
char ioq[2*MAXQSIZE+10];        //Input/Outputbuffer fuer async-Manager
static uint serstat;            //Daten empfangen ?
static int errcode;             //fuer async-fkts
static int size;                //fuer async-fkts
static uchar *postoread;        //fuer async-fkts
static int bytestoread;         //fuer async-fkts
static int dummy;               //fuer async-fkts
static long sertimakt;          //Startzeitpunkt timeout
static int sertiminterval;      //Timeoutzeit
static char irotbuf[IROTBUFSIZE]; //Sendebuffer
static uchar irotrbuf[IROTBUFSIZE];//Empfangsbuffer
static int irotstate;           //Phase der Uebertragung
static int irothstate;          //Teil-Phase der Uebertragung
static uint irwritecnt;         //# Bytes zu schreiben fuer Systemaufrufe
static uint irreadcnt;          //# Bytes zu lesen fuer Systemaufrufe
static uint iroterrcnt;         //Retrycounter
static uchar timeoutrunning;    //async Systemfunktion gestartet (Timer)
static uchar readrunning;       //async Systemfunktion gestartet (read)
static uint crc;                //Pruefsumme
static uchar receivecnt;        //Empfangszaehler ddcmp
static uchar sendcnt;           //Sendezaehler ddcmp
static uchar blockcnt;          //Datenblockzaehler fuer Senden */
static int bytessend;           //# Bytes zuletzt gesendet (fuer retry)
static int byteread;            //# Bytes zuletzt gelesen
static uchar irotdataflag;      //ob Daten vollstaendig empfangen wurden
                                //und ob Daten wiederholt empfangen wurden
static long datenlaenge;        //Rest # Bytes zu lesen laut READ-RESPONSE
static long reclaenge;          //# Bytes zu lesen laut Datenheader
static long restreclaenge;      //# Bytes noch zu lesen (Teil von reclaenge)
static long posfile;            //Position am File (fuer Rewind, falls Daten
                                //erneut kommen)
static uchar listnum;           //zu lesende Liste
static int spno = 1;            //serial Port number
static int quickflag = 0;		//benuetze 19200 statt 9600
static char filename[FNAMSIZE];
static char binfname[FNAMSIZE+2];


static unsigned long filesize;

//ctrl-messages
static char msgstart[] = {0x05, 0x06, 0x40, 0x00, 0x00, 0x01};
static char msgstack[] = {0x05, 0x07, 0x40, 0x00, 0x00, 0x01, 0x00, 0x00};
static char msgack[] =   {0x05, 0x01, 0x40, 0x00, 0x00, 0x01, 0x00, 0x00};
static char msgnack[] =  {0x05, 0x02, 0x40, 0x00, 0x00, 0x01, 0x00, 0x00};


//spezielle Kennungen fuer z.B. "Program Slave Device"
static char securitycode[] = {0x00, 0x00};
static char passcode[] = {0x00, 0x00};
static char iruserid[] = {0x00, 0x00};
static char sernummer[8] = {0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30};
static char accesstype;

static int statistikerr1 = 0;
static int statistikerr2 = 0;
static int statistikerr3 = 0;
static int statistikzap  = 0;
static int statistiknack = 0;

//was zu tun ist
static char doprogflag = 0;
static char doinpflag = 0;
static char doclearflag = 0;
static char dooutpflag = 0;
static char timestring[20];
static int binfnamesize = 0;
static int verbosecnts = 0;
static int verbosecntr = 0;
static int verbosecnte = 0;


static uchar toutvals[] = {
  //timeout-Zeiten je nach Zustand
  12,  // WT_STACK 
  12,  // WT_ACK   
  12,  // WT_ACKD  
  12,  // WT_ACKF  
  200,// WT_DHDR  
  200,// WT_DATA  
  0,  // WT_START
};

void timemde(char *pbuf){
  //liefert im Puffer Datum und Zeit in folgender Form zurueck:
  //ddmmyyhhmmss  entsprechend who are you command (packed pcd)
  time_t systime;
  struct tm *dt;

  if(*timestring){
    strcpy(pbuf,timestring);
  }
  else {
    time(&systime);
    dt = localtime(&systime);
    sprintf(pbuf,"%02u%02u%02u%02u%02u%02u",
    dt->tm_mday/*+1*/,dt->tm_mon + 1,(dt->tm_year)%100,dt->tm_hour,dt->tm_min,dt->tm_sec);
  }
  pbuf[0] = (char)(pbuf[0] - '0') << 4 | (pbuf[1] - '0');
  pbuf[1] = (char)(pbuf[2] - '0') << 4 | (pbuf[3] - '0');
  pbuf[2] = (char)(pbuf[4] - '0') << 4 | (pbuf[5] - '0');
  pbuf[3] = (char)(pbuf[6] - '0') << 4 | (pbuf[7] - '0');
  pbuf[4] = (char)(pbuf[8] - '0') << 4 | (pbuf[9] - '0');
  pbuf[5] = (char)(pbuf[10] - '0') << 4 | (pbuf[11] - '0');
}

//extern int __far g0timdif(int);

//#define DELAYLOOP 1
volatile int xxx;
#ifdef DELAYLOOP
int deldauer = 8000; //255
static void switchdelay(void){
  int i;
//  int dtime;

//  g0timdif(-4);
  for(i = 0;i < deldauer;i++){
    xxx = i;
  }

  //read timer
//  dtime = g0timdif(-4);

//  fprintf(stderr,"\ndeltat: %d\n",dtime);
}
#else

#pragma intrinsic(_inp,_outp,_disable,_enable)
//Delay ueber Systemtimer von ca 3 ms
static void switchdelay(void){
  int oldtimerhigh;
  int newtimerhigh;
  int i;
  int k;
  static char firstflag = 1;

  //timer 0 in betriebsart 2 versetzen 
  if(firstflag){
    firstflag = 0;
    _disable();
    _outp(0x43,0x34);
    _outp(0x40,0);
    _outp(0x40,0);
    _enable();
  }
  //read timer
  _disable();
  _outp(0x43,4);
  _inp(0x40);
  oldtimerhigh = ~_inp(0x40);
  _enable();
  for(k = 0;k < 5000;k++){
    //kurzes Delay, damit Interrupts zwischendurch frei sind
    for(i = 0;i < 50;i++){
      xxx = i;
    }
    _disable();
    _outp(0x43,4);
    _inp(0x40);
    newtimerhigh = ~_inp(0x40);
    _enable();
    if(newtimerhigh - oldtimerhigh > 12 || newtimerhigh < oldtimerhigh) return;
  }
}

#endif

static void starttimeout(void){
  //starte Uhrtimer 
  if (quickflag) 
    sertiminterval = toutvals[irothstate] * 2;
  else
    sertiminterval = toutvals[irothstate];
  if(sertiminterval){
    sertimakt = TICKCNT;
    timeoutrunning = 1;
  }
}

static void stoptimeout(void){
  //cancel timeout
  timeoutrunning = 0;
}

static void stopread(void){
  //cancel read
  readrunning = 0;
  serstat = 0;
}

static void zapinput(void){
  statistikzap++;
  verbosecnte++;
  stopread();
  for(;;){
    switchdelay();
    errcode = qsize_a1(spno,&size,&serstat);
    if(errcode != OK){
      if(verboseflag){
        fprintf(stderr,"\nERROR serial port\n");
      }
      exit(5);
    }
    if(!size) return;
    errcode = iflsh_a1(spno); //clear read buf
    if(errcode != OK){
      if(verboseflag){
        fprintf(stderr,"\nERROR serial port\n");
      }
      exit(5);
    }
  }
}



int testcrc(uchar *buf,int cnt){ //bei cnt Bufflaenge ohne crc angeben!
  uchar     bitcnt;
  uchar     flg;

  for(;cnt--;){
    crc ^= *(uchar*)buf++; //CRC mit Polynom 0xa001 (1 + x**2 + x**15 + x**16) */
    bitcnt = 8;
    do {
      flg = crc & 1;
      crc >>= 1;
      if (flg)
        crc ^= 0xa001;
    } while (--bitcnt);
  }
  if(*(uchar*)buf++ == (crc & 0xff) && *(uchar*)buf == (crc >> 8 & 0xff)){
    return(0); //crc ok
  }
  return(-1); //crc error
}

void setcrc(char *buf,int cnt){ //bei cnt Bufflaenge ohne crc angeben!
  uchar     bitcnt;
  uchar     flg;

  for(crc = 0;cnt--;){
    crc ^= *(uchar*)buf++; //CRC mit Polynom 0xa001 (1 + x**2 + x**15 + x**16) */
    bitcnt = 8;
    do {
      flg = crc & 1;
      crc >>= 1;
      if (flg)
        crc ^= 0xa001;
    } while (--bitcnt);
  }
  *buf++ = crc & 0xff;
  *buf = crc >> 8 & 0xff;
}




static void closeser(void){
  close_a1(spno);
}

static int openirot(void){
  errcode = open_a1(spno,MAXQSIZE,MAXQSIZE,0,0,ioq);
  if(errcode){
    if(verboseflag){
      fprintf(stderr,"\nERROR %d open serial port\n",errcode);
    }
    exit(5);
  }
  atexit(closeser);
  if (quickflag)
	errcode = setop_a1(spno,1,8);  // 19200 Baud
  else
  	errcode = setop_a1(spno,1,7);  // 9600 Baud
  if(errcode){
    if(verboseflag){
      fprintf(stderr,"\nERROR %d setting BAUD-rate\n",errcode);
    }
    exit(5);
  }
  errcode = setop_a1(spno,2,0);  // no parity
  if(errcode){
    if(verboseflag){
      fprintf(stderr,"\nERROR %d setting parity\n",errcode);
    }
    exit(5);
  }
  errcode = setop_a1(spno,3,3);  // 8 Data-Bits
  if(errcode){
    if(verboseflag){
      fprintf(stderr,"\nERROR %d setting 8 Data-Bits\n",errcode);
    }
    exit(5);
  }
  errcode = setop_a1(spno,4,0);  // 1 Stopbit
  if(errcode){
    if(verboseflag){
      fprintf(stderr,"\nERROR %d setting 1 Stopbit\n",errcode);
    }
    exit(5);
  }
  errcode = setop_a1(spno,9,0);  // no CTS
  if(errcode){
    fprintf(stderr,"ERR setop nr %d\n",errcode);
    exit(5);
  }
  if (quickflag) {
	  errcode = setop_a1(spno,12,0x0b);  // set handshakes, undocumented functions
	  if(errcode){
	    fprintf(stderr,"ERR setop nr %d\n",errcode);
	    exit(5);
	  }
	  errcode = setop_a1(spno,13,0x09);  // set handshakes
	  if(errcode){
	    fprintf(stderr,"ERR setop nr %d\n",errcode);
	    exit(5);
	  }
	  errcode = setop_a1(spno,14,0x09);  // set handshakes
	  if(errcode){
	    fprintf(stderr,"ERR setop nr %d\n",errcode);
	    exit(5);
	  }
  } else {
	  errcode = setop_a1(spno,12,0x0b);  // set handshakes, undocumented functions
	  if(errcode){
	    fprintf(stderr,"ERR setop nr %d\n",errcode);
	    exit(5);
	  }
	  errcode = setop_a1(spno,13,0x0a);  // set handshakes
	  if(errcode){
	    fprintf(stderr,"ERR setop nr %d\n",errcode);
	    exit(5);
	  }
	  errcode = setop_a1(spno,14,0x0a);  // set handshakes
	  if(errcode){
	    fprintf(stderr,"ERR setop nr %d\n",errcode);
	    exit(5);
	  }
  }
  return(0);
}


static int resend(int wcnt,int rcnt,int rpos){
  long htimeout;

  stopread();
  bytessend = wcnt;
  if(wcnt){
    errcode = wrtst_a1(spno,wcnt,irotbuf,&irwritecnt);
    if(errcode != OK){
      if(verboseflag){
        fprintf(stderr,"\nERROR serial port\n");
      }
      exit(5);
    }
    htimeout = TICKCNT;
    for(;;){
      errcode = oqsiz_a1(spno,&size);
      if(errcode != OK){
        if(verboseflag){
          fprintf(stderr,"\nERROR serial port\n");
        }
        exit(5);
      }
      if(!size) break;
      if(htimeout > TICKCNT || TICKCNT > htimeout + 20){
        if(verboseflag){
          fprintf(stderr,"\nERROR PSION not ready for communication (RTS/CTS\?\?)\n");
        }
        exit(2);
      }
    }
  }
  if(rcnt){
    //warte auf Empfang
    bytestoread = rcnt;
    irreadcnt = 0;
    postoread = &irotrbuf[rpos];
    readrunning = 1;
    //stelle Timer fuer Timeout
    stoptimeout();
    starttimeout();
  }
  return(0);
}

static int sendctrl(char *buf){
  long htimeout;

  stopread();
  setcrc(buf,6);
  irwritecnt = 8;
  errcode = wrtst_a1(spno,8,buf,&irwritecnt);
  if(errcode != OK){
    if(verboseflag){
      fprintf(stderr,"\nERROR serial port\n");
    }
    exit(5);
  }
  htimeout = TICKCNT;
  for(;;){
    errcode = oqsiz_a1(spno,&size);
    if(errcode != OK){
      if(verboseflag){
        fprintf(stderr,"\nERROR serial port\n");
      }
      exit(5);
    }
    if(!size) break;
    if(htimeout > TICKCNT || TICKCNT > htimeout + 20){
      if(verboseflag){
        fprintf(stderr,"\nERROR PSION not ready for communication (RTS/CTS\?\?)\n");
      }
      exit(2);
    }
  }
  return(0);
}

static int sendnack(char msg){
  statistiknack++;
  msgnack[2] = msg;
  msgnack[3] = receivecnt - 1;
  if(sendctrl(msgnack)) return -1;
  return(resend(0,8,0));
}

static int sendack(){
  msgack[3] = receivecnt++;
  return(sendctrl(msgack));
}

static void setdatahdr(int size){
  irotbuf[0] = 0x81;
  irotbuf[1] = size & 0xff;
  irotbuf[2] = 0x40 | size >> 8 & 0xff;
  irotbuf[3] = receivecnt - 1;
  irotbuf[4] = sendcnt;
  irotbuf[5] = 1;
  setcrc(irotbuf,6);
}

static int sendfinish(void){
  //sende FINISH
  irothstate = WT_ACKF;
  setdatahdr(2); //Laenge ohne CRC !
  irotbuf[8] = 0x77;
  irotbuf[9] = 0xff;
  setcrc(&irotbuf[8],2);
  return(resend(12,8,0));
}

static void initirot(int typ){
  if(typ < 0){
    //cancel timer usw.
    stoptimeout();
    stopread();
    _close(fd);
    return;
  }
  irotstate = S_START; //Anforderungsphase gestartet
  irothstate = WT_STACK;
  sendcnt = 1;
  receivecnt = 1;
  iroterrcnt = 0;
  timeoutrunning = 0;
  accesstype = 0x0c;
  openirot();
  //sende START
  memcpy(irotbuf,msgstart,6);
  setcrc(irotbuf,6);
  zapinput(); //z.B. falls von Gegenseite noch von frueheren Versuchen Daten anstehen
  resend(8,8,0);
  return;
}


static int readsend(void){
  //baut Datenbloecke zum Senden mit bis zu 237 Byte Daten auf
  //etwaig noetige Konvertierungen, Update von Datum etc wurden bereits
  //vorher durch extra Programm vorgenommen
  //return: 0: ok, noch nicht fertig
  //return: 1: ok, fertig (nichts mehr gesendet)
  //return: -1: Fehler
  long len;

  irotbuf[8] = 0x99;
  irotbuf[9] = blockcnt++;
  if(binfnamesize){
    len = binfnamesize;
    binfnamesize = 0;
    strcpy(&irotbuf[10],binfname);
  }
  else {
    len = filesize;
    if(len > IROTWRITEBYTES){
      len = IROTWRITEBYTES;
    }
    if(len == 0) return 1;
    len = _read(fd,&irotbuf[10],len);
    if(len == 0) return 1;
    if(len < 0){
      if(verboseflag){
        fprintf(stderr,"\nERROR reading inputfile\n");
      }
      exit(1);
    }
  }
  filesize -= len;
  len += 2;
  sendcnt++; //Nr fuer naechste Sendung setzen
  setcrc(&irotbuf[8],len);
  setdatahdr(len);
  verbosecnts++;
  return(resend(len+10,8,0)); //+ DHDR + CRC
}

static int setfilesize(){
  //sucht auf der Inputdatei ab der aktuellen Position nach CRLF FILE*
  //bzw EOF; setzt filesize auf Laenge bis FILE und restauriert aktuelle
  //Position
#define SBUFSIZE 512
  long startpos;
  long endpos;
  long pos;
  char searchbuf[SBUFSIZE];
  int len;
  int state;
  static char sstring[] = "FILE*";
  char *p1;

  startpos = _tell(fd);
  if(startpos < 0){
    if(verboseflag){
      fprintf(stderr,"\nERROR reading inputfile\n");
    }
    exit(1);
  }
  if(binfnamesize){ //File binaer vollstaendig uebertragen, nicht durchsuchen
    endpos = _filelength(fd);
    if(endpos < 0){
      if(verboseflag){
        fprintf(stderr,"\nERROR reading inputfile\n");
      }
      exit(1);
    }
    filesize = endpos + binfnamesize;
//  _lseek(fd,startpos,SEEK_SET);
    return(0);
  }
  for(pos = startpos,state = 0;;){
    len = _read(fd,searchbuf,SBUFSIZE);
    if(len < 0){
      if(verboseflag){
        fprintf(stderr,"\nERROR reading inputfile\n");
      }
      exit(1);
    }
    if(len == 0){
      filesize = pos - startpos;
      _lseek(fd,startpos,SEEK_SET);
      if(filesize){
        return(0);
      }
      else {
        return(-1);
      }
    }
    for(p1 = searchbuf;p1 < &searchbuf[len];p1++){
      if(*p1 == CR || *p1 == LF){
        endpos = pos + (long)(p1 - searchbuf) + 1;
        state = 1;
        continue;
      }
      if(!state) continue;
      if(*p1 == sstring[state - 1]){
        if(!sstring[state]){
          filesize = endpos - startpos;
          _lseek(fd,startpos,SEEK_SET);
          if(filesize){
            return(0);
          }
          else {
            return(-1);
          }
        }
        state++;
        continue;
      }
      state = 0;
    }
    pos += len;
  }
}

static int writercv(char *buf,int cnt){
  //schreibt cnt Bytes von buf auf das scratchfile
  //return: 0: ok

  verbosecntr++;
  if(_write(fd,buf,cnt) == cnt) return(0);
  if(verboseflag){
    fprintf(stderr,"\nERROR writing outputfile\n");
  }
  exit(1);
}

static int doprog(void){
  //sende PROGRAMSLAVEDEVICE
  setdatahdr(24); //Laenge ohne CRC !
  irotbuf[8] = 0x77;
  irotbuf[9] = 0xe1;
  irotbuf[10] = 0;
  memcpy(&irotbuf[11],securitycode,2);
  memcpy(&irotbuf[13],passcode,2);
  timemde(&irotbuf[15]);
  memcpy(&irotbuf[21],iruserid,2);
  irotbuf[23] = accesstype;
  memcpy(&irotbuf[24],sernummer,8);
  setcrc(&irotbuf[8],24);
  irotstate = S_PROGRESP;
  irothstate = WT_ACKD;
  return(resend(34,8,0));
}

static int doinput(void){
  //sende READDATA
  setdatahdr(9); //Laenge ohne CRC !
  irotbuf[8] = 0x77;
  irotbuf[9] = 0xe2;
  irotbuf[10] = 0;
  irotbuf[11] = listnum;
  irotbuf[12] = 1; //recno
  irotbuf[13] = 0; //byteoffset low
  irotbuf[14] = 0; //byteoffset high
  irotbuf[15] = 0; //segment length low (complete record)
  irotbuf[16] = 0; //segment length high (complete record)
  setcrc(&irotbuf[8],9);
  irotstate = S_READRESP;
  irothstate = WT_ACKD;
  return(resend(19,8,0));
}

static int doclear(void){
  //sende DELETEDATA
  setdatahdr(5); //Laenge ohne CRC !
  irotbuf[8] = 0x77;
  irotbuf[9] = 0xe4;
  irotbuf[10] = 0;
  irotbuf[11] = listnum;
  irotbuf[12] = 1; //recno
  setcrc(&irotbuf[8],5);
  irotstate = S_CLEARRESP;
  irothstate = WT_ACKD;
  return(resend(15,8,0));
}

static int dooutput(void){
  //sende WRITEDATA
  if(setfilesize()){
    //nichts mehr zu schreiben
    irotstate = S_READY;
    return sendfinish();
  }
  setdatahdr(6); //Laenge ohne CRC !
  irotbuf[8] = 0x77;
  irotbuf[9] = 0xe3;
  irotbuf[10] = 0;
  irotbuf[11] = listnum;
  irotbuf[12] = filesize & 0xff;   //recsize low
  irotbuf[13] = filesize >> 8 & 0xff;  //recsize high
  setcrc(&irotbuf[8],6);
  irotstate = S_WRITERESP;
  irothstate = WT_ACKD;
  return(resend(16,8,0));
}

void delay1s(){ //1s Verzoegerung
  long tickend;

  tickend = TICKCNT + 20;

  for(;;){
    if(TICKCNT > tickend) return;
  }
}


int recirot(int toflag){
  //wird aufgerufen, wenn Daten empfangen wurden (toflag = 0)
  //oder timeout auftrat (toflag = 1)
  //oder ein asynchroner write fertig ist (toflag = 2) (nur bei PC-Uebertragung)
  //returncodes: 0: OK
  //            -1: Abbruch
  //             1: Uebertragung abgeschlossen
  char *p1;
  int rval;

  switch(irothstate){
    //Hilfsautomat
  case WT_STACK: //warte auf Start ACK
    crc = 0;
    if(serstat != 0 || irotrbuf[0] != 0x05 || irotrbuf[1] != 0x07 ||
      toflag || testcrc(irotrbuf,6)){
      //Uebertragungsfehler
      if(++iroterrcnt > MAXERRRETRYSTART){
        if(verboseflag){
          fprintf(stderr,"\nERROR data transmission fault (too many retrys during START)\n");
        }
        exit(3);
      }
      zapinput();
      return(resend(8,8,0));
    }
    break; //Start ACK erfolgreich empfangen
  case WT_ACK: //warte auf ACK
  case WT_ACKD: //warte auf ACK und anschliessend DHDR
  case WT_ACKF: //warte auf final ACK
    if(serstat != 0 || toflag){
      //klare Fehler vorab abfangen, dann wird der Rest besser lesbar
      statistikerr1++;
      if(++iroterrcnt > MAXERRRETRY){
        if(verboseflag){
          fprintf(stderr,"\nERROR data transmission fault (too many retrys)\n");
        }
        exit(3);
      }
      zapinput();
      return(resend(bytessend,8,0));
    }
    crc = 0;
    if((irotrbuf[0] != 0x05 || irotrbuf[1] != 0x01 /* ACK */ &&
      irotrbuf[1] != 0x02 /* NACK */) && irotrbuf[0] != 0x81 /* DHDR */ ||
      irotrbuf[3] != sendcnt || testcrc(irotrbuf,6)){
      //Uebertragungsfehler
      statistikerr2++;
      if(++iroterrcnt > MAXERRRETRY){
        if(verboseflag){
          fprintf(stderr,"\nERROR data transmission fault (too many retrys)\n");
        }
        exit(3);
      }
      zapinput();
      return(resend(bytessend,8,0));
    }
    if(irothstate == WT_ACKD){
      iroterrcnt = 0;
      irothstate = WT_DHDR;
      irotdataflag = 0;
      if(irotrbuf[0] == 0x81){
        //erlaube pickyback ACK
        if(irotrbuf[4] != receivecnt){
          zapinput();
          return(sendnack(1));
        }
        goto dhdrempfangen;
      }
      return(resend(0,8,0));
    }
    break; //ACK oder NACK oder DHDR erfolgreich empfangen
  case WT_DHDR: //warte auf Data Header
    if(serstat != 0 || toflag){
      //klare Fehler vorab abfangen, dann wird der Rest besser lesbar
      statistikerr1++;
      if(++iroterrcnt > MAXERRRETRY){
        if(verboseflag){
          fprintf(stderr,"\nERROR data transmission fault (too many retrys)\n");
        }
        exit(3);
      }
      zapinput();
      return(sendnack(1));
    }
    crc = 0;
    if(irotrbuf[0] != 0x81 || irotrbuf[4] != receivecnt || testcrc(irotrbuf,6)){
      //Uebertragungsfehler
      statistikerr2++;
      if(++iroterrcnt > MAXERRRETRY || toflag){
        if(verboseflag){
          fprintf(stderr,"\nERROR data transmission fault (too many retrys)\n");
        }
        exit(3);
      }
      zapinput();
      return(sendnack(1));
    }
dhdrempfangen:
    reclaenge = (irotrbuf[2] & 0x3f) << 8 | irotrbuf[1];
    restreclaenge = reclaenge + 2; //zuzueglich CRC
    byteread = (int) restreclaenge;
    if((unsigned) byteread > IRREADANZ){
      if(restreclaenge - IRREADANZ < 2){
        byteread = IRREADANZ - 1;
      }
      else {
        byteread = IRREADANZ;
      }
    }
    iroterrcnt = 0;
    irothstate = WT_DATA;
    irotdataflag |= IRDATAFIRST;
    crc = 0;
    return(resend(0,byteread,0));
    break; //DHDR erfolgreich empfangen
  case WT_DATA: // warte auf Data
    if(toflag){
      if(verboseflag){
        fprintf(stderr,"\nERROR data transmission fault (timeout)\n");
      }
      exit(3);
      //Timeoutzeit hier lange genug, dass Sender genuegend viele
      //retrys ausfuehren kann
    }
    if(serstat != 0 || restreclaenge <= byteread && testcrc(irotrbuf,byteread-2)){ 
      if(serstat != 0){
        statistikerr1++;
      }
      if(++iroterrcnt > MAXERRRETRY){
        if(verboseflag){
          fprintf(stderr,"\nERROR data transmission fault (too many retrys)\n");
        }
        exit(3);
      }
      zapinput();
      irothstate = WT_DHDR;
      if(restreclaenge < reclaenge + 2){
        irotdataflag |= IRDATAAGAIN;
        //evtl. Filepointer zuruecksetzen, da Daten nochmals kommen
      }
      return(sendnack(2));
    }
    restreclaenge -= byteread;
    if(restreclaenge > 0){
      testcrc(irotrbuf,byteread);
      break;
    }
    irotdataflag |= IRDATACOMPLETE; //alle im DHDR angegebenen Bytes erfolgreich gelesen
    break;
  }
  iroterrcnt = 0;


  switch(irotstate){
  case S_START:
    //STACK empfangen, sende who are you
    setdatahdr(16); //Laenge ohne CRC !
    irotbuf[8] = 0x77;
    irotbuf[9] = 0xe0;
    irotbuf[10] = 0;
    memcpy(&irotbuf[11],securitycode,2);
    memcpy(&irotbuf[13],passcode,2);
    timemde(&irotbuf[15]);
    memcpy(&irotbuf[21],iruserid,2);
    irotbuf[23] = accesstype;
    setcrc(&irotbuf[8],16);
    irotstate = S_WAY;
    irothstate = WT_ACKD;
    return(resend(26,8,0));
  case S_WAY:
    //teste, ob WAY-Response
    if(!(irotdataflag & IRDATACOMPLETE) || irotrbuf[0] != 0x88 ||
      irotrbuf[1] != 0xe0){
      if(verboseflag){
        fprintf(stderr,"\nERROR data transmission fault (not WAY-response)\n");
      }
      exit(3);
    }
    sendack();
    sendcnt++; //Nr fuer naechste Sendung setzen
    if(irotrbuf[2] != 1){
      //Steuerung lehnt ab (z.B. wegen Passwort) sollte bei PSION nicht sein
      if(verboseflag){
        fprintf(stderr,"\nERROR data transmission fault (WAY rejected)\n");
      }
      exit(3);
    }
    if(doprogflag){
      return(doprog());
    }
    if(doinpflag){
      return(doinput());
    }
    if(doclearflag){
      return(doclear());
    }
    if(dooutpflag){
      return(dooutput());
    }
    irotstate = S_READY;
    return sendfinish();
    break;
  case S_REFUSED:
    //Steuerung hat abgelehnt und Finish mit ACK beantwortet
    return(-1);
  case S_READRESP:
    //teste, ob READ-Response
    if(!(irotdataflag & IRDATACOMPLETE) || irotrbuf[0] != 0x88 ||
      irotrbuf[1] != 0xe2){
      if(verboseflag){
        fprintf(stderr,"\nERROR data transmission fault (not READ-response)\n");
      }
      exit(3);
    }
    sendack();
    if(irotrbuf[2] != 1){
      //Steuerung lehnt ab (keine Files mehr)
      sendcnt++; //Nr fuer naechste Sendung setzen
      if(doclearflag){
        return(doclear());
      }
      irotstate = S_READY;
      return sendfinish();
    }
    datenlaenge = irotrbuf[8] << 8 | irotrbuf[7];
    posfile = 0; //FILEPREFIXSIZE;
    irotstate = S_READ;
    irothstate = WT_DHDR;
    return(resend(0,8,0));
  case S_PROGRESP:
    //teste, ob PROG-Response
    if(!(irotdataflag & IRDATACOMPLETE) || irotrbuf[0] != 0x88 ||
      irotrbuf[1] != 0xe1){
      if(verboseflag){
        fprintf(stderr,"\nERROR data transmission fault (not PROG-response)\n");
      }
      exit(3);
    }
    sendack();
    sendcnt++; //Nr fuer naechste Sendung setzen
    if(irotrbuf[2] != 1){
      //Steuerung lehnt ab
      if(verboseflag){
        fprintf(stderr,"\nERROR data transmission fault (PROG rejected)\n");
      }
      exit(3);
    }
    if(doinpflag){
      return(doinput());
    }
    if(doclearflag){
      return(doclear());
    }
    if(dooutpflag){
      return(dooutput());
    }
    irotstate = S_READY;
    return sendfinish();
  case S_WRITERESP:
    //teste, ob WRITE-Response
    if(!(irotdataflag & IRDATACOMPLETE) || irotrbuf[0] != 0x88 ||
      irotrbuf[1] != 0xe3){
      if(verboseflag){
        fprintf(stderr,"\nERROR data transmission fault (not WRITE-response)\n");
      }
      exit(3);
    }
    sendack();
    if(irotrbuf[2] != 1){
      //Steuerung lehnt ab
      if(verboseflag){
        fprintf(stderr,"\nERROR data transmission fault (WRITE rejected)\n");
      }
      exit(3);
    }
    blockcnt = 0;
    //Daten senden
    if(readsend()){
      return -1;
    }
    irotstate = S_WRITE;
    irothstate = WT_ACK;
    break;
  case S_CLEARRESP:
    //teste, ob CLEAR-Response
    if(!(irotdataflag & IRDATACOMPLETE) || irotrbuf[0] != 0x88 ||
      irotrbuf[1] != 0xe4){
      if(verboseflag){
        fprintf(stderr,"\nERROR data transmission fault (not DELETE-response)\n");
      }
      exit(3);
    }
    sendack();
    sendcnt++; //Nr fuer naechste Sendung setzen
    if(irotrbuf[2] != 1){
      //Steuerung lehnt ab
      if(verboseflag){
        fprintf(stderr,"\nERROR data transmission fault (DELETE rejected)\n");
      }
      exit(3);
    }
    if(dooutpflag){
      return(dooutput());
    }
    irotstate = S_READY;
    return sendfinish();
  case S_READ:
    if(irotdataflag & IRDATAAGAIN){
      //Daten waren schon mal (fehlerhaft) da, Filepointer zuruecksetzen
      if(_lseek(fd,posfile,SEEK_SET) < 0){
        if(verboseflag){
          fprintf(stderr,"\nERROR seeking on inputfile\n");
        }
        exit(1);
      }
    }
    if(irotdataflag & IRDATAFIRST){
      p1 = (char*)&irotrbuf[2]; //skip Blocknummer
      byteread -= 2;
    }
    else {
      p1 = (char*)irotrbuf;
    }

    if(irotdataflag & IRDATACOMPLETE){
      if(writercv(p1,byteread - 2) < 0) return(-1);
      posfile += reclaenge - 2;
      irotdataflag = 0;
      sendack();
      datenlaenge -= reclaenge - 2;
      if(datenlaenge > 0){
        irothstate = WT_DHDR;
        return(resend(0,8,0));
      }
      else {
        //Daten vollstaendig empfangen (vom letzten READDATA)
        sendcnt++; //Nr fuer naechste Sendung setzen
        return(doinput());
      }
    }
    if(writercv(p1,byteread) < 0) return(-1);
    byteread = (int)restreclaenge;
    if((unsigned) byteread > IRREADANZ){
      if(restreclaenge - IRREADANZ < 2){
        byteread = IRREADANZ - 1;
      }
      else {
        byteread = IRREADANZ;
      }
    }
    irotdataflag = 0;
    return(resend(0,byteread,0));
  case S_READY:
    return 1;
  case S_WRITE:
    rval = readsend();
    if(rval == 0) return 0;
    if(rval < 0) return -1;
    //Daten vollstaendig gesendet
    sendcnt++; //Nr fuer naechste Sendung setzen
    delay1s();
    return(dooutput());
  }
}


static void printusage(void){
  fprintf(stderr,
  "\nDDCMP-VIDTS Communication Version 1.04\nCopyright (c) 1993-1995 mikrolab GmbH\n");
  fprintf(stderr,"\nusage:\n");
  fprintf(stderr," ddcmp /L listnum /I inputfile [/C] [/D[DDMMYYhhmmss]] [/V] [/2]\n");
  fprintf(stderr,"   or\n");
  fprintf(stderr," ddcmp /L listnum /O outputfile [/C] [/D[DDMMYYhhmmss]] [/V] [/2]\n");
  fprintf(stderr,"   or\n");
  fprintf(stderr," ddcmp /L listnum /C [/D[DDMMYYhhmmss]] [/V] [/2]\n");
  fprintf(stderr,"   or\n");
  fprintf(stderr," ddcmp /D[DDMMYYhhmmss] [/V] [/2]\n");
  fprintf(stderr,"\nOptions:\n");
  fprintf(stderr," /C: Clear MDE\n");
  fprintf(stderr," /D: Set date and time\n");
  fprintf(stderr," /V: Verbose\n");
  fprintf(stderr,"\nexit codes:\n");
  fprintf(stderr,"  0: OK\n");
  fprintf(stderr,"  1: error reading or writing inputfile/outputfile\n");
  fprintf(stderr,"  2: error PSION not ready for communication\n");
  fprintf(stderr,"  3: data transmission fault\n");
  fprintf(stderr,"  4: commandline error (this message)\n");
  fprintf(stderr,"  5: error serial port\n");
  fprintf(stderr,"--- more ---");
  getch();
  fprintf(stderr,"\n\n\nlistnum:\n");
  fprintf(stderr,"  1  or 2:   read-out data       (PSION-dir: saetze)\n");
  fprintf(stderr,"  64 or 100: config data         (PSION-dir: conf)\n");
  fprintf(stderr,"  101:       man-read-out data   (PSION-dir: mansaetz)\n");
  fprintf(stderr,"  102:       report data         (PSION-dir: notizen)\n");
  fprintf(stderr,"  103:       filling data        (PSION-dir: fuellm)\n");
  fprintf(stderr,"  104:       init data           (PSION-dir: servdat)\n");
  fprintf(stderr,"  105:       lock data           (PSION-dir: sperrdat)\n");
  fprintf(stderr,"\n\n\n\n");



  exit(4);
}

static void getargs(char **argv){
  char fileset = 0;
  char listset = 0;
  char portset = 0;
  char *p1;
  char *p2;

  for(;*++argv;){
    p1 = *argv;
    if(*p1 == '/'){
      switch(*++p1){
      default:
        printusage();
        break;
      case 'L':
      case 'l':
        if(listset){
          printusage();
        }
        if(!*++p1){
          if(!(p1 = *++argv) || !*p1){
            printusage();
          }
        }
        for(listnum = 0;*p1;listnum = listnum * 10 + *p1++ - '0');
        listset = 1;
        break;
      case 'I':
      case 'i':
        if(fileset){
          printusage();
        }
        dooutpflag = 1;
        if(!*++p1){
          if(!(p1 = *++argv) || !*p1){
            printusage();
          }
        }
        for(p2 = filename;(*p2++ = *p1) && p2 < &filename[FNAMSIZE-1];p1++);
        if(*p1){
          printusage();
        }
        if(!(fd = _open(filename,_O_BINARY | _O_RDONLY))){
          if(verboseflag){
            fprintf(stderr,"\nERROR opening inputfile\n");
          }
          exit(1);
        }
        fileset = 1;
        break;
      case 'O':
      case 'o':
        if(fileset){
          printusage();
        }
        doinpflag = 1;
        if(!*++p1){
          if(!(p1 = *++argv) || !*p1){
            printusage();
          }
        }
        for(p2 = filename;(*p2++ = *p1) && p2 < &filename[FNAMSIZE-1];p1++);
        if(*p1){
          printusage();
        }
        if(!(fd = _open(filename,_O_BINARY | _O_CREAT | _O_TRUNC | _O_RDWR,_S_IWRITE))){
          if(verboseflag){
            fprintf(stderr,"\nERROR opening outputfile\n");
          }
          exit(1);
        }
        fileset = 1;
        break;
      case 'C':
      case 'c':
        if(doclearflag){
          printusage();
        }
        doclearflag = 1;
        break;
      case 'D':
      case 'd':
        if(doprogflag){
          printusage();
        }
        doprogflag = 1;
        *timestring = 0;
        if(!*++p1){
          if(!argv[1] || *argv[1] == '/') break; // D ohne weiter spec
          p1 = *++argv;
        }
        for(p2 = timestring;p2 < &timestring[12];*p2++ = *p1++){
          if(*p1 < '0' || *p1 > '9'){
            printusage();
          }
        }
        if(*p1){
          printusage();
        }
        break;
      case 'B':
      case 'b':
        if(binfnamesize){
          printusage();
        }
        if(!*++p1){
          if(!argv[1] || *argv[1] == '/'){
            // B ohne weiter spec
            if(!dooutpflag){ // /I war noch nicht da
              printusage();
            }
            //filename vom Inputfile uebernehmen
            //strip leading path
            for(p1 = filename;*p1;p1++);
            for(;p1 >= filename && *p1 != '/' && *p1 != '\\' && *p1 != ':';p1--);
            if(!*++p1){
              printusage();
            }
          }   
          else {
            p1 = *++argv;
          }
        }
        p2 = binfname;
        *p2++ = 'F'; *p2++ = 'I'; *p2++ = 'L'; *p2++ = 'E'; *p2++ = '*';
        for(;*p1;*p2++ = *p1++);
        *p2++ = CR;
        *p2++ = LF;
        *p2 = 0;
        binfnamesize = p2 - binfname;
        break;
      case '2':
        if(portset){
          printusage();
        }
        spno = 2;
        portset = 1;
        break;
      case 'V':
      case 'v':
        verboseflag = !verboseflag;
        break;
      case 'q':
      case 'Q':
        quickflag = 1;
        break;
      }
    }  
    else {
      printusage();
    }
  }
  if(!listset && (doinpflag || dooutpflag || doclearflag) ||
    !doinpflag && !dooutpflag && !doprogflag && !doclearflag
    || binfnamesize && !dooutpflag){
    printusage();
  }
}


void main(int argc,char** argv){
  int rval;

  getargs(argv);
  serstat = 0;
  timeoutrunning = 0;
  initirot(0);
  //hole Parameter vom Prozessaufruf

  for(;;){
    if(readrunning){
      errcode = rdst_a1(spno,bytestoread,postoread,&size,&dummy,&serstat);
      if(errcode != OK && errcode != IN_Q_EMPTY){
        if(verboseflag){
          fprintf(stderr,"\nERROR serial port\n");
        }
        exit(5);
      }
      irreadcnt += size;
      postoread += size;
      bytestoread -= size;
      if(bytestoread <= 0){
        readrunning = 0;
        rval = recirot(0);
        if(!rval) continue; // alles ok
        initirot(-1); //close IR
        if(rval > 0){
          if(verboseflag){
            fprintf(stderr,"\nTRANSMISSION OK\n");
          }
          exit(0); //signalisiere ready
        }
        else {
          if(verboseflag){
            fprintf(stderr,"\nTRANSMISSION ERROR\n");
          }
          exit(3);
        }
      }
    }
    if(timeoutrunning && TICKCNT > sertimakt + sertiminterval || TICKCNT < sertimakt){
      timeoutrunning = 0;
      rval = recirot(1);
      if(!rval) continue; // alles ok
      initirot(-1); //close IR
      if(verboseflag){
        fprintf(stderr,"\nTRANSMISSION ERROR\n");
      }
      exit(3);
    }
    {
      static int xx = 0;
      if(verboseflag && ++xx > 1000){ 
        xx = 0;
        if(verbosecnts > 0){
          verbosecnts--;
          fprintf(stderr,"S");
        }
        else {
          if(verbosecntr > 0){
            verbosecntr--;
            fprintf(stderr,"R");
          }
          else {
            if(verbosecnte > 0){
              verbosecnte--;
              fprintf(stderr,"E");
            }
            else {
              fprintf(stderr,"."); //damit Unterbrechungsmoeglichkeit im CV
            }
          }
        }
      }
    }
  }
}
