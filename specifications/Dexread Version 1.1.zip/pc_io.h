   /**********************************************************************
	File Name:		pc_io.h

	Description :	Header file for pc_io.cpp

   Author:			Coin Acceptors Europe Ltd. - Engineering Dept.

	Environment:	Borlands C++ v5.02 Pentium/233 64mb RAM Win95

	Version:			v1.0		08/Mar/1999

	Project Ref:	9903-SWR-01.0
	*********************************************************************/

	/* ----------------------- EXTERNAL VARIABLES -------------------*/
	extern int Port;									// serial communications port
	extern void spin();
	/* ----------------------- GLOBAL VARIABLES ------------------------ */
	void 	FlushCom();
	int	portbase = 0;
	void 	interrupt(*oldvects[2])(...);
	boolean	COMactivated;

	char    	ccbuf[SBUFSIZ],sgetsbuf[200];
	unsigned int	startbuf = 0;
	unsigned int	endbuf = 0;


